import os
import requests
import zipfile
import subprocess
import psutil
import time

CURRENT_EXE_NAME = 'MugenTool.exe'
CURRENT_EXE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), CURRENT_EXE_NAME)
TEMP_ZIP_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'temp_atualizacao.zip')

GITHUB_TOKEN = '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'

current_directory = os.path.dirname(os.path.abspath(__file__))  # Pasta atual (_internal)
parent_directory = os.path.dirname(current_directory)  # Pasta anterior à atual (MugenTool)
ZIP_FILE_NAME = 'MugenTool.zip'
ZIP_PATH = os.path.join(parent_directory, ZIP_FILE_NAME)

def get_current_version():
    return "1.5"

def get_latest_version():
    try:
        headers = {
            'Authorization': f'token {GITHUB_TOKEN}',
            'Accept': 'application/vnd.github.v3+json'
        }
        response = requests.get('https://api.github.com/repos/TrilhaX/ReLauncher/releases/latest', headers=headers)
        if response.status_code == 200:
            return response.json()['tag_name'].lstrip('v')
        else:
            print("Erro ao obter a versão mais recente:", response.status_code)
            return None
    except Exception as e:
        print("Ocorreu um erro:", e)
        return None

def download_update():
    print("Baixando atualização...")
    try:
        headers = {
            'Authorization': f'token {GITHUB_TOKEN}',
            'Accept': 'application/vnd.github.v3+json'
        }
        response = requests.get('https://api.github.com/repos/TrilhaX/ReLauncher/releases/latest', headers=headers)
        if response.status_code == 200:
            assets = response.json().get('assets', [])
            for asset in assets:
                if asset['name'] == 'MugenTool.zip':
                    download_url = asset['url']
                    zip_response = requests.get(download_url, headers={'Authorization': f'token {GITHUB_TOKEN}', 'Accept': 'application/octet-stream'})
                    if zip_response.status_code == 200:
                        with open(TEMP_ZIP_PATH, 'wb') as file:
                            file.write(zip_response.content)
                        print("Atualização baixada com sucesso.")
                        return True
                    else:
                        print("Erro ao baixar o arquivo ZIP:", zip_response.status_code)
                        return False
    except Exception as e:
        print("Ocorreu um erro ao tentar baixar a atualização:", e)
    return False

def wait_for_zip(zip_path, timeout=30):
    print(f"Aguardando o arquivo ZIP aparecer: {zip_path}")
    elapsed_time = 0
    wait_interval = 1  # Verificar a cada 1 segundo

    while not os.path.exists(zip_path):
        if elapsed_time >= timeout:
            print(f"Tempo limite atingido ({timeout} segundos) e o arquivo ZIP ainda não apareceu.")
            return False
        time.sleep(wait_interval)
        elapsed_time += wait_interval

    print(f"O arquivo ZIP foi encontrado: {zip_path}")
    return True

def kill_existing_process():
    # Função que tenta matar o processo associado ao executável
    for process in os.popen('tasklist').read().strip().split('\n'):
        if 'MugenTool.exe' in process:
            os.system('taskkill /f /im MugenTool.exe')
            print("Processo MugenTool.exe finalizado.")

def extract_update():
    # Verificar se o ZIP existe no diretório atual
    if not wait_for_zip(ZIP_PATH):
        print(f"Erro: O arquivo {ZIP_PATH} não foi encontrado no tempo permitido.")
        return

    try:
        print(f"Extraindo o arquivo ZIP: {ZIP_PATH}")
        
        # Garantir que o processo do executável antigo seja finalizado antes de removê-lo
        kill_existing_process()

        # Extrair no mesmo diretório onde o ZIP está localizado
        extract_path = os.path.dirname(ZIP_PATH)  # Extrair no diretório do ZIP
        
        with zipfile.ZipFile(ZIP_PATH, 'r') as zip_ref:
            zip_ref.printdir()
            zip_ref.extractall(extract_path)  # Extrair todo o conteúdo no diretório do ZIP
            print(f"Conteúdo extraído com sucesso para {extract_path}.")
        
        # Remover o arquivo executável antigo
        if os.path.exists(CURRENT_EXE_PATH):
            os.remove(CURRENT_EXE_PATH)
            print(f"Executável antigo removido: {CURRENT_EXE_PATH}")
        
        # Remover o arquivo ZIP
        os.remove(ZIP_PATH)
        print(f"ZIP removido com sucesso: {ZIP_PATH}")
        
    except zipfile.BadZipFile:
        print("Erro: O arquivo ZIP está corrompido.")
    except Exception as e:
        print(f"Ocorreu um erro ao tentar extrair o ZIP: {e}")


def install_update():
    if os.path.exists(CURRENT_EXE_PATH):
        kill_existing_process()
        print("Removendo versão antiga do MugenTool...")
        os.remove(CURRENT_EXE_PATH)

    print("Instalando atualização...")
    download_update()

    # Colocando o MugenTool.zip na pasta anterior à _internal
    current_directory = os.path.dirname(os.path.abspath(__file__))  # Pasta atual (_internal)
    parent_directory = os.path.dirname(current_directory)  # Pasta anterior à atual
    destination_zip_path = os.path.join(parent_directory, 'MugenTool.zip')  # Caminho do novo ZIP

    os.rename(TEMP_ZIP_PATH, destination_zip_path)  # Move o ZIP para o destino
    print(f"O arquivo MugenTool.zip foi movido para: {destination_zip_path}")

    # Extrair o ZIP
    extract_update()
    print("Atualização instalada com sucesso.")

def clear_cmd():
    subprocess.call('cls' if os.name == 'nt' else 'clear', shell=True)

def wait_for_keypress():
    input("\nPressione Enter para fechar...")

def main():
    current_version = get_current_version()
    latest_version = get_latest_version()

    if latest_version and current_version != latest_version:
        clear_cmd()
        user_input = input("Você deseja instalar a atualização? (s/n): ").strip().lower()
        if user_input == 's':
            install_update()
            print("Atualização concluída.")
        else:
            print("Atualização não instalada.")
    else:
        print("Você já está usando a versão mais recente.")
    
    wait_for_keypress()

if __name__ == "__main__":
    main()